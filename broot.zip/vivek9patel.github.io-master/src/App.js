import Ubuntu from "./components/ubuntu";

function App() {
  return <Ubuntu />;
}

export default App;
